#pragma once

class FastBot2Client;