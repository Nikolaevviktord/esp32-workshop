#pragma once

namespace fb {

class Core;

extern Core* thisBot;

}