#include "core_class.h"

namespace fb {

Core* thisBot = nullptr;

}