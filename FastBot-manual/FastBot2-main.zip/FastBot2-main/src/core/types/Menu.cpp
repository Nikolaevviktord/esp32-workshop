#include "Menu.h"

namespace fb {

bool Menu::persistentDefault = 0;
bool Menu::resizeDefault = 0;
bool Menu::oneTimeDefault = 0;
bool Menu::selectiveDefault = 0;

}