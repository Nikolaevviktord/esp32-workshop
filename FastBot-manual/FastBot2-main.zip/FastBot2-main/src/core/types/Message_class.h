#pragma once

namespace fb {
class Message;
}