#include "Message.h"

namespace fb {

bool Message::previewDefault = 1;
bool Message::notificationDefault = 1;
bool Message::protectDefault = 0;
Message::Mode Message::modeDefault = Message::Mode::Text;

}